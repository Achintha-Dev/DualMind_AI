import { GoogleGenerativeAI } from '@google/generative-ai';
import config from '../config/config_index.js';

const genAI = new GoogleGenerativeAI(config.gemini.apiKey);

export async function runAnalyst(question, history = [], options = {}) {
  console.log('Analyst received history:', history); // Debug log
  
  const model = genAI.getGenerativeModel({ model: "models/gemini-3.1-flash-lite" });
  
  // Convert history to Gemini format
  const geminiHistory = history.map(msg => ({
    role: msg.role, // Already 'user' or 'model' from chatService
    parts: [{ text: msg.text }]
  }));

  // Use startChat to preserve conversation context
  const chat = model.startChat({
    history: geminiHistory,
    generationConfig: {
      maxOutputTokens: options.maxOutputTokens || 800,
      temperature: 0.7,
    }
  });

  const start = Date.now();
  const result = await chat.sendMessage(question);
  const response = await result.response;
  const text = response.text();
  
  return {
    text,
    tokens: response.usageMetadata?.totalTokenCount || 0
  };
}
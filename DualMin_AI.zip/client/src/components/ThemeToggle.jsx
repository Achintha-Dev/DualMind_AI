import { useTheme } from '../hooks/useTheme';
import moonIcon from '../assets/moon_icon.svg';

function ThemeToggle() {
    const { toggleTheme, isDark } = useTheme();

    return (
        <div className=' pr-6 pl-5 '>
            <label className="swap swap-rotate cursor-pointer hover:scale-125 ">
                {/* 1. 'checked' syncs the visual toggle state with React context.
                  2. 'onChange' fires toggleTheme() whenever a user clicks it.
                */}
                <input 
                    type="checkbox" 
                    checked={isDark} 
                    onChange={toggleTheme} 
                />

                {/* DaisyUI Swap Mechanics:
                  - swap-on shows up when the input checkbox is CHECKED (Dark Mode)
                  - swap-off shows up when the input checkbox is UNCHECKED (Light Mode)
                */}
                {/* sun icon displays when dark mode is active */}
                <svg
                    className="swap-on fill-current dark:text-white w-6 h-6 "
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24">
                    <path
                    d="M5.64,17l-.71.71a1,1,0,0,0,0,1.41,1,1,0,0,0,1.41,0l.71-.71A1,1,0,0,0,5.64,17ZM5,12a1,1,0,0,0-1-1H3a1,1,0,0,0,0,2H4A1,1,0,0,0,5,12Zm7-7a1,1,0,0,0,1-1V3a1,1,0,0,0-2,0V4A1,1,0,0,0,12,5ZM5.64,7.05a1,1,0,0,0,.7.29,1,1,0,0,0,.71-.29,1,1,0,0,0,0-1.41l-.71-.71A1,1,0,0,0,4.93,6.34Zm12,.29a1,1,0,0,0,.7-.29l.71-.71a1,1,0,1,0-1.41-1.41L17,5.64a1,1,0,0,0,0,1.41A1,1,0,0,0,17.66,7.34ZM21,11H20a1,1,0,0,0,0,2h1a1,1,0,0,0,0-2Zm-9,8a1,1,0,0,0-1,1v1a1,1,0,0,0,2,0V20A1,1,0,0,0,12,19ZM18.36,17A1,1,0,0,0,17,18.36l.71.71a1,1,0,0,0,1.41,0,1,1,0,0,0,0-1.41ZM12,6.5A5.5,5.5,0,1,0,17.5,12,5.51,5.51,0,0,0,12,6.5Zm0,9A3.5,3.5,0,1,1,15.5,12,3.5,3.5,0,0,1,12,15.5Z" />
                </svg>

                {/* moon icon displays when light mode is active */}
                <img src={moonIcon} alt="Moon" className="swap-off w-6 h-6" />
            </label>
        </div>
    );
}

export default ThemeToggle;
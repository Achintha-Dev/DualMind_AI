import axios from 'axios';

const api = axios.create({
    baseURL : 'http://loaclhost:5000/api'
});

// automatically attach token if user logged in
// guest user → no token
// logged user → token attached automatically

api.interceptors.request.use((config) => {

    const token = localStorage.getItem('token');

    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }

    return config;

});

export default api;